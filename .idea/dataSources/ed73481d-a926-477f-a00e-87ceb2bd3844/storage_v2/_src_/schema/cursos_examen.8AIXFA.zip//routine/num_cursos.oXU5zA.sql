create
    definer = root@localhost function num_cursos(dni_profesor char(9)) returns int reads sql data
begin
		declare var_num_cursos integer;
		select count(curso) into var_num_cursos
			from profesores as p left join cursos_profesores as cp
								on p.dni = cp.profesor
			where p.dni = dni_profesor;
        return var_num_cursos;
    end;

