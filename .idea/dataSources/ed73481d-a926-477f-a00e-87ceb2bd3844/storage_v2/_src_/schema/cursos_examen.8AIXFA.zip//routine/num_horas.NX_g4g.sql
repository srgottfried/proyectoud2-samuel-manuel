create
    definer = root@localhost function num_horas(dni_profesor char(9)) returns int reads sql data
begin
		declare var_horas integer;
		select sum(numero_horas) into var_horas
			from profesores as p left join cursos_profesores as cp
								on p.dni = cp.profesor
			where p.dni = dni_profesor;
            
		if (var_horas is null) then
			set var_horas = 0;
		end if;
        
        return var_horas;
    end;

