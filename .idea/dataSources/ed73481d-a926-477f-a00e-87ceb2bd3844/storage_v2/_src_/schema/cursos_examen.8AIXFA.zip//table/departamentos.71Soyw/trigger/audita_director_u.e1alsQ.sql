create definer = root@localhost trigger audita_director_u
    after update
    on departamentos
    for each row
begin 
		insert into audita_departamentos values
			(concat("ACTUALIZACIÓN de director: ", old.director, " -> ", new.director));
    end;

