create definer = root@localhost trigger control_director_i
    before insert
    on departamentos
    for each row
begin
		if (new.director in (select distinct tutor from cursos)) then
			signal sqlstate '45001' set message_text = "El director ya tiene un cargo de tutor actualmente.";
        end if;
    end;

